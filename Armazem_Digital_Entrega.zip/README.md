# Armazém Digital — API REST

## Descrição

Projeto acadêmico desenvolvido para o gerenciamento de produtos por meio de uma API REST, utilizando Node.js, Express e MongoDB.

A API permite cadastrar, consultar, atualizar e excluir produtos, além de validar os dados recebidos nas requisições.

## Tecnologias utilizadas

- Node.js
- Express
- MongoDB
- Mongoose
- JavaScript
- Postman

## Requisitos

- Node.js instalado.
- MongoDB Community Server instalado e em execução.
- npm (gerenciador de pacotes do Node.js).

## Instalação

1. Clone ou extraia o projeto.
2. Abra a pasta do projeto no terminal.
3. Instale as dependências:

```bash
npm install
```

4. Configure o arquivo `.env` na raiz do projeto:

```env
PORT=3000
MONGODB_URI=mongodb://127.0.0.1:27017/armazem_digital
```

## Execução

Para iniciar em modo de desenvolvimento:

```bash
npm run dev
```

Para iniciar normalmente:

```bash
npm start
```

A API estará disponível em:

`http://localhost:3000`

Para verificar se está funcionando, acesse:

`http://localhost:3000/saude`

Resposta esperada:

```json
{
  "status": "ok"
}
```

## Rotas disponíveis

Base URL: `http://localhost:3000/api/produtos`

| Método | Rota | Descrição |
|---|---|---|
| GET | /api/produtos | Listar produtos |
| GET | /api/produtos/:id | Buscar produto por ID |
| POST | /api/produtos | Cadastrar produto |
| PATCH | /api/produtos/:id | Atualizar produto |
| DELETE | /api/produtos/:id | Excluir produto |

## Exemplo de cadastro

**POST /api/produtos**

```json
{
  "nome": "Teclado",
  "descricao": "Teclado mecânico",
  "preco": 150,
  "quantidade": 10
}
```

## Validações implementadas

- Nome obrigatório, com tamanho entre 2 e 100 caracteres.
- Descrição com limite de 500 caracteres.
- Preço numérico e não negativo.
- Quantidade numérica, inteira e não negativa.
- Campo ativo do tipo booleano.
- Rejeição de campos não permitidos.
- Validação de IDs do MongoDB.
- Tratamento de JSON inválido.
- Tratamento de erros e recursos não encontrados.

## Códigos HTTP utilizados

- 200 — Requisição realizada com sucesso.
- 201 — Produto cadastrado.
- 204 — Produto excluído.
- 400 — Dados ou ID inválidos.
- 404 — Produto ou rota não encontrados.
- 413 — JSON excede o limite permitido.
- 500 — Erro interno do servidor.

## Persistência

Os produtos são armazenados no MongoDB, no banco de dados `armazem_digital`, coleção `produtos`.

## Coleção Postman

O projeto inclui o arquivo:

`Armazem_Digital.postman_collection.json`

Esse arquivo contém as requisições utilizadas para testar as operações da API e pode ser importado no Postman.

## Estrutura do projeto

```text
armazem-digital/
├── src/
│   ├── config/
│   │   └── db.js
│   ├── controllers/
│   │   └── produtoController.js
│   ├── middlewares/
│   │   ├── validarProduto.js
│   │   └── erros.js
│   ├── models/
│   │   └── Produto.js
│   ├── routes/
│   │   └── produtoRoutes.js
│   └── server.js
├── .env.example
├── .gitignore
├── package.json
├── package-lock.json
├── README.md
└── Armazem_Digital.postman_collection.json
```

## Projeto acadêmico

Trabalho prático de desenvolvimento de API REST com Node.js, Express e MongoDB.